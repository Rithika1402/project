import { BrowserRouter,Routes,Route } from 'react-router-dom';
import  NewComponent  from  ''

import React from 'react'

function App() {
  return (
    <div className='App'>App
    <BrowserRouter>
    <Routes>
      <Route path='/count' element={<CountingFunction/>}/>
      </Routes></BrowserRouter>
    </div>
  )
}

export default App