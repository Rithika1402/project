import React, { Component } from 'react'

export default class ClassComponent extends Component {
    constructor() {
        super();
        this.state = {

        msg: 'welcome'
        };

    }
  render() {
    return (
      <div>
        <h1>{this.state.msg}</h1>
      </div>
    )
  }
}
