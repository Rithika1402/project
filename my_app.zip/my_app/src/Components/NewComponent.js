import React from 'react'

function GreetingComponent(props) {
  return (
    <div>
      <h1>Hello Good Morning{props.name}</h1>
      <h1>hello everyone{props.age}</h1>
    </div>
  )
}

export default GreetingComponent